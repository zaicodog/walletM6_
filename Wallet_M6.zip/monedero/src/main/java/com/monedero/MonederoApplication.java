package com.monedero;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MonederoApplication {

	public static void main(String[] args) {
		SpringApplication.run(MonederoApplication.class, args);
	}

}
